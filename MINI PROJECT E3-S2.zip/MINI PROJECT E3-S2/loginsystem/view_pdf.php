<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kgf";
// $var=21;
// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Get the file ID from the query parameter
if (isset($_GET['subject'])) {
    $fileId = $_GET['subject'];
    // Retrieve the file data and file name from the database
    $sql = "SELECT file, file_name FROM upload WHERE subject='$fileId'";
    $result = $conn->query($sql);

    if ($result === false) {
        echo "Error executing query: " . $conn->error;
    } else {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fileData = $row['file'];
            $fileName = $row['file_name'];

            // Get the file extension
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            // Set appropriate headers for file output
            switch ($fileExtension) {
                case 'pdf':
                    header("Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                    break;
                // case 'jpg':
                case 'jpeg':
                    header("Content-type: image/jpeg");
                    break;
                case 'png':
                    header("Content-type: image/png");
                    break;
                case 'gif':
                    header("Content-type: image/gif");
                    break;
                case 'doc':
                    header("Content-type: application/msword");
                    break;
                case 'docx':
                    header("Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                    break;
                case 'ppt':
                    header("Content-type: application/vnd.ms-powerpoint");
                    break;
                default:
                    header("Content-type: application/octet-stream");
                    break;
            }

            header("Content-Disposition: inline; filename=$fileName");

            // Output the file data
            echo $fileData;
        } else {
            echo "File not found.";
        }
    }
} else {
    echo "Invalid file ID.";
}

// Close the connection
$conn->close();
?>
