<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Welcome - <?php $_SESSION['username']?></title>
  </head>
  <body>
    <?php require 'partials/_nav.php' ?>
    Welcome - <?php echo $_SESSION['username']?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>



<?php require 'partials/_nav.php' ?>
    <?php
    if($showAlert){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your account is now created and you can login
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    } 
    ?> 






<?php require 'partials/_nav.php' ?>
    <?php
    if($login){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> You are logged in
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    ?>



<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kgf";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<?php
$id = $_GET['id']; // Assuming you have the fileId as a parameter

// Prepare and execute a query to retrieve the file from the database
$query = "SELECT file_name FROM files WHERE id = ?";
$statement = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($statement, "i", $id);
mysqli_stmt_execute($statement);
mysqli_stmt_bind_result($statement, $file_name);

// Fetch the result
if (mysqli_stmt_fetch($statement)) {
    // Set appropriate headers for the file
    // header("Content-type: $filetype");
    header("Content-disposition: inline; file_name=\"$file_name\"");

    // Output the file data
    echo $file_name;
}

// Close the statement and database connection
mysqli_stmt_close($statement);
mysqli_close($connection);
?>











// // Get the file ID from the query parameter
// if (isset($_GET['file_name'])) {
//     $fileId = $_GET['file_name'];

//     // Retrieve the file data and file name from the database
//     $sql = "SELECT file_name FROM upload WHERE file_name= shilpa_aid.pdf";
//     $result = $conn->query($sql);
//     if ($result === false) {
//         echo "Error executing query: " . $conn->error;
//     } else {
//         if ($result->num_rows > 0) {
//             $row = $result->fetch_assoc();
//             $fileData = $row['file'];
//             $fileName = $row['file_name'];
//             // Get the file extension
//             $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
//             // Set appropriate headers for file output
//             switch ($fileExtension) {
//                 case 'pdf':
//                     header("Content-type: application/pdf");
//                     break;
//                 case 'jpg':
//                 case 'jpeg':
//                     header("Content-type: image/jpeg");
//                     break;
//                 case 'png':
//                     header("Content-type: image/png");
//                     break;
//                 case 'gif':
//                     header("Content-type: image/gif");
//                     break;
//                 case 'doc':
//                     header("Content-type: application/msword");
//                     break;
//                 case 'docx':
//                     header("Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
//                     break;
//                 case 'ppt':
//                     header("Content-type: application/vnd.ms-powerpoint");
//                     break;
//                 default:
//                     header("Content-type: application/octet-stream");
//                     break;
//             }

//             header("Content-Disposition: inline; filename=$fileName");

//             // Output the file data
//             echo $fileData;
//         } else {
//             echo "File not found.";
//         }
//     }
// } else {
//     echo "Invalid file ID.";
// }

// // Close the connection
// $conn->close();
// ?>




