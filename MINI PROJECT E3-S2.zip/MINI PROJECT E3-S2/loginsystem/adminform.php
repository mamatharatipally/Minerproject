<html>
<head>
    <title>My Xerox</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        
        h1 {
            margin-bottom: 20px;
            font-size: 36px;
            text-align: center;
            text-transform: uppercase;
            color: #333;
        }
        
        form {
            max-width: 400px;
            margin: 0 auto;
        }
        
        .form-group {
            display: flex;
            flex-direction: row;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .form-group label {
            flex: 1;
            font-weight: bold;
            margin-right: 10px;
        }
        .amount{
            font-weight: bold;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="number"],
        .form-group input[type="file"] {
            flex: 2;
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        
        img {
            display: block;
            max-width: 150px;
            height: auto;
            margin-bottom: 15px;
        }
        
        input[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>My Xerox</h1>
	<form action="store_data.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="myFile">File:</label>
            <input type="file" id="myFile" name="myFile" required>
        </div>
        <input type="submit" value="Submit">
    </form>
    <script src="script.js"></script>
</body>
</html>
