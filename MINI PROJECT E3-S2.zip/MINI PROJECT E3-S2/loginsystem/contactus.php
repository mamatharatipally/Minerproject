<?php
$showAlert = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include './partials/_dbconnect.php';
    $name = $_POST["name"];
    $email = $_POST["email"];
    $mess = $_POST["message"];
    $exists=false;
   
        $sql = "INSERT INTO `query` ( `name`, `email`, `queries`) VALUES ('$name', '$email', '$mess')";
        $result = mysqli_query($conn, $sql);
        if ($result){
            $showAlerts = true;
        }
        header("location: index.html");
}
    
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student's Ecorner| MyOnline.com</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" media="screen and (max-width: 1170px)" href="css/phone.css">
    <link href="https://fonts.googleapis.com/css?family=Baloo+Bhai|Bree+Serif&display=swap" rel="stylesheet">
</head>
<body>
    <nav id="navbar">
        <div id="logo">
            <img src="logo.jpg" alt="MyOnlineMeal.com">
        </div>
        <ul>
            <li class="item"><a href="index.html">Home</a></li>
           
        </ul>
    </nav>
    
        <section id="contact">
            <h1 class="h-primary center">Contact Us</h1>
            <div id="contact-box">
                <form action="/loginsystem/contactus.php" method="post">
                    <div class="form-group">
                        <label for="name">Name: </label>
                        <input type="text" name="name" id="name" placeholder="Enter your name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email: </label>
                        <input type="email" name="email" id="email" placeholder="Enter your email">
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Message: </label>
                        <textarea name="message" id="message" cols="30" rows="10"></textarea>
                    </div>
                    <div> <button type="submit" class="btn btn-primary">Submit</button></div>

                </form>
            </div>
        </section>
        
        <footer>
            <div class="center">
                Copyright &copy; www.myecourse.com. All rights reserved!
            
            </div>
        </footer>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    </html>