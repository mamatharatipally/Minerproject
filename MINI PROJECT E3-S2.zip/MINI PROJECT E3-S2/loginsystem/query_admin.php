<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";
// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve all rows from a table
$sql = "SELECT * FROM query";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data in an HTML table
    echo "<table style='border-collapse: collapse; width: 100%; background-color:powderblue'>";
    echo "<tr><th style='border: 1px solid #000; padding: 8px;'>ID</th><th style='border: 1px solid #000; padding: 8px;'>Name</th><th style='border: 1px solid #000; padding: 8px;'>Email</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td style='border: 1px solid #000; padding: 8px;'>" . $row["name"] . "</td>";
        echo "<td style='border: 1px solid #000; padding: 8px;'>" . $row["email"] . "</td>";
        echo "<td style='border: 1px solid #000; padding: 8px;'>" . $row["queries"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No records found";
}

// Close the database connection
$conn->close();
?>

