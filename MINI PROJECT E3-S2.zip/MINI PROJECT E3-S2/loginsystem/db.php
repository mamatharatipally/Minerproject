<?php
$host="localhost:3306";
$user="root";
$pass="";
$db="kgf";
$conn=mysqli_connect($host,$user,$pass,$db);
?>