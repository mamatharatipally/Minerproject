<!DOCTYPE html>
<html>
<head>
    <title>User Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            margin-bottom: 20px;
            font-size: 36px;
            text-align: center;
            text-transform: uppercase;
            color: #333;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .action-links a {
            margin-right: 5px;
            text-decoration: none;
        }

        .action-links a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function confirmDelete(rowId) {
            if (confirm("Are you sure you want to delete this row?")) {
                window.location.href = "delete_row.php?id=" + rowId;
            }
        }

        function sendEmail(rowId, email) {
            if (confirm("Are you sure you want to mark this work as done and send an email?")) {
                window.location.href = "send_email.php?id=" + rowId + "&email=" + email;
            }
        }
    </script>
</head>
<body>
    <h1>User Data</h1>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kgf";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve all data from the table
    $sql = "SELECT * FROM xerox_table";
    $result = $conn->query($sql);

    if ($result === false) {
        echo "Error executing query: " . $conn->error;
    } else {
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Name</th><th>Email</th><th>Phone Number</th><th>Address</th><th>Number of Copies</th><th>File Name</th><th>Payment Proof</th><th>Action</th></tr>";

            // Loop through each row
            while ($row = $result->fetch_assoc()) {
                $name = $row['name'];
                $email = $row['email'];
                $phone = $row['phone_number'];
                $address = $row['address'];
                $copies = $row['copies'];
                $fileName = $row['file_name'];
                $paymentProofFileName = $row['payment_proof_file_name'];
                $fileId = $row['id'];

                // Display the data
                echo "<tr>";
                echo "<td>$name</td>";
                echo "<td>$email</td>";
                echo "<td>$phone</td>";
                echo "<td>$address</td>";
                echo "<td>$copies</td>";
                echo "<td>$fileName</td>";
                echo "<td><a href='view_payment_proof.php?id=$fileId' target='_blank'>$paymentProofFileName</a></td>";
                echo "<td class='action-links'>";
                echo "<a href='view_pdf.php?id=$fileId' target='_blank'>View</a>";
                echo "<a href='javascript:void(0)' onclick='sendEmail($fileId, \"$email\")'>Done</a>";
                echo "<a href='javascript:void(0)' onclick='confirmDelete($fileId)'>Delete</a>";
                echo "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No data found.";
        }
    }

    // Close the connection
    $conn->close();
    ?>
</body>
</html>
