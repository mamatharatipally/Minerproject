<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kgf";
// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Retrieve user input from the form
$file = $_FILES['myFile']['tmp_name'];
$fileName = $_FILES['myFile']['name'];
$subject = $_FILES['myFile']['name'];
// Prepare and bind the SQL query with placeholders
$stmt = $conn->prepare("INSERT INTO upload (file_name, file,subject) VALUES (?, ?, ?)");
$stmt->bind_param("sss",$fileName, $file,$subject);
// Read the file data and bind it to the query parameters
// Execute the statement
if ($stmt->execute()) {
    echo "Data stored successfully.";
} else {
    echo "Error storing data: " . $stmt->error;
} 
// Close the statement
$stmt->close();
// Close the connection
$conn->close();
?>

